/**
 * <b> CS 180 - Project 4 - Chat Server Skeleton </b>
 * <p>
 * <p>
 * This is the skeleton code for the ChatServer Class. This is a private chat
 * server for you and your friends to communicate.
 *
 * @author Neil Nachnani nnachnan@purdue.edu
 * Tejaswi Kotekar tkotekar@purdue.edu
 * @version November 20th, 2015
 * @lab Neil - BR8
 * Tejaswi - LC2
 */
public class SessionCookie {
    public static int timeoutLength = 300;
    private long id;
    private static long time;
    private int min = 0000;
    private int max = 9999;
    private int[] idList = new int[10000];
    private SessionCookie neil;

    public SessionCookie(long id) {
        this.id = id;
        this.time = System.currentTimeMillis();
    }

    public long getID() {
        return this.id;
    }

    public SessionCookie() {
    }
    //method returns the ID of the cookie

    public boolean hasTimedOut() {
        if (System.currentTimeMillis() - SessionCookie.time > timeoutLength * 1000) {
            //changed this.time to SessionCookie.time
            return true;
        } else return false;

    }

    public void updateTimeOfActivity() {
        this.time = System.currentTimeMillis();

    } //method will update the cookie's time of last activity by setting it to the current time


}
